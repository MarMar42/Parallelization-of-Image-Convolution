To compile the code, run the make file as follows:
	To compile convolution.cu: make all
	To remove the output file: make clean